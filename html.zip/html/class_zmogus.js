var class_zmogus =
[
    [ "Zmogus", "class_zmogus.html#aa7a8ba4d3c4778f9b35d59eef3e72574", null ],
    [ "getName", "class_zmogus.html#ad09081a9463b42b80eba2ea745877095", null ],
    [ "getSurname", "class_zmogus.html#a4f6dc26fb4b6a63bff6b7c4021c196c6", null ],
    [ "setPerson", "class_zmogus.html#a7e1c9611fd558e2375a7e9724b4a5a7f", null ],
    [ "pavarde_", "class_zmogus.html#a95b83ef4d9bbe9b88d78c17563bafa5a", null ],
    [ "vardas_", "class_zmogus.html#a09b290c9be6039ce3a94e1557def9b3a", null ]
];