var files_dup =
[
    [ "Build", "dir_4335ce4a64d0d4f9f4c8f0a782dfdfeb.html", "dir_4335ce4a64d0d4f9f4c8f0a782dfdfeb" ],
    [ "v1.2", "dir_90e2b144347bea472a204d82082c1348.html", "dir_90e2b144347bea472a204d82082c1348" ]
];