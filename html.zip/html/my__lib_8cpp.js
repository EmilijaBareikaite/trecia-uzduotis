var my__lib_8cpp =
[
    [ "a_paz_tikrinimas", "my__lib_8cpp.html#a4823ab3c9f123cb409e2bbed9e34eee8", null ],
    [ "budo_patikrinimas", "my__lib_8cpp.html#ac2856fbcf9a4dd1d38f53dbefaa5995a", null ],
    [ "egzamino_tikrinimas", "my__lib_8cpp.html#a2747d98f3a7caf5a0dde8c33dc18a9d6", null ],
    [ "failo_skaitymas", "my__lib_8cpp.html#a248c32f8b851286b2119a99ad7ed0385", null ],
    [ "generate_random_mark", "my__lib_8cpp.html#a984b4252c352e01a48a56c7d6a54d454", null ],
    [ "Generavimas_failo", "my__lib_8cpp.html#ad40eb40134f8f6a319bb735ed5a6d11a", null ],
    [ "LyginimasPagalPavarde", "my__lib_8cpp.html#a060e6bb1eef334f831188cf647b257f3", null ],
    [ "LyginimasPagalRezultata", "my__lib_8cpp.html#a328b415bddedc8fb24dbcdc9be755c20", null ],
    [ "LyginimasPagalVarda", "my__lib_8cpp.html#ab4cb4e46b5ff87bdfa546f3153eef05c", null ],
    [ "mediana", "my__lib_8cpp.html#a920378be8b928748dda8ff60b0763591", null ],
    [ "mokiniu_sk_patikrinimas", "my__lib_8cpp.html#ac8c05db9a4f3b82dfb20bddbcc8c11c6", null ],
    [ "Vidurkis", "my__lib_8cpp.html#a4e65559221ffbc2e147c3a1b799bea8e", null ]
];