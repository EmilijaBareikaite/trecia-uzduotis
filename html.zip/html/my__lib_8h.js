var my__lib_8h =
[
    [ "Zmogus", "class_zmogus.html", "class_zmogus" ],
    [ "Studentas", "class_studentas.html", "class_studentas" ],
    [ "a_paz_tikrinimas", "my__lib_8h.html#a4823ab3c9f123cb409e2bbed9e34eee8", null ],
    [ "budo_patikrinimas", "my__lib_8h.html#ac2856fbcf9a4dd1d38f53dbefaa5995a", null ],
    [ "egzamino_tikrinimas", "my__lib_8h.html#a2747d98f3a7caf5a0dde8c33dc18a9d6", null ],
    [ "failo_skaitymas", "my__lib_8h.html#a248c32f8b851286b2119a99ad7ed0385", null ],
    [ "generate_random_mark", "my__lib_8h.html#a984b4252c352e01a48a56c7d6a54d454", null ],
    [ "Generavimas_failo", "my__lib_8h.html#ad40eb40134f8f6a319bb735ed5a6d11a", null ],
    [ "isrusiuotas_spausdinimas", "my__lib_8h.html#af6171464ab0ca0ab7de11c08a376d5d1", null ],
    [ "isvedimas_m", "my__lib_8h.html#a7bc55580234cb86361001a578827dfb5", null ],
    [ "isvedimas_v", "my__lib_8h.html#a43082488f6da19d8b8b47073b2cec5eb", null ],
    [ "LyginimasPagalPavarde", "my__lib_8h.html#a5340c4bd90062dfd25b1c33de617bfc9", null ],
    [ "LyginimasPagalRezultata", "my__lib_8h.html#a453a7a5c13e9d67a89e07c0903fce9ee", null ],
    [ "LyginimasPagalVarda", "my__lib_8h.html#a6963630624dc9474b854f98a9904c2c9", null ],
    [ "mediana", "my__lib_8h.html#a920378be8b928748dda8ff60b0763591", null ],
    [ "mokiniu_sk_patikrinimas", "my__lib_8h.html#ac8c05db9a4f3b82dfb20bddbcc8c11c6", null ],
    [ "padalinimas_v_3", "my__lib_8h.html#a9e4f894e033e0f94b8c3983de6bc7d9b", null ],
    [ "Vidurkis", "my__lib_8h.html#a4e65559221ffbc2e147c3a1b799bea8e", null ]
];