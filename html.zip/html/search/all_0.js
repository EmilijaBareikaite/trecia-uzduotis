var searchData=
[
  ['a_5fpaz_5ftikrinimas_0',['a_paz_tikrinimas',['../my__lib_8cpp.html#a4823ab3c9f123cb409e2bbed9e34eee8',1,'a_paz_tikrinimas(int &amp;a_paz_kiekis):&#160;my_lib.cpp'],['../my__lib_8h.html#a4823ab3c9f123cb409e2bbed9e34eee8',1,'a_paz_tikrinimas(int &amp;a_paz_kiekis):&#160;my_lib.cpp']]]
];
