var searchData=
[
  ['gautidydi_0',['GautiDydi',['../class_studentas.html#ad433e509c1d2fa1f6a7094648b16fe75',1,'Studentas']]],
  ['gautiegzamina_1',['GautiEgzamina',['../class_studentas.html#a45265140e28d9caa99b540e366464d53',1,'Studentas']]],
  ['generate_5frandom_5fmark_2',['generate_random_mark',['../my__lib_8h.html#a984b4252c352e01a48a56c7d6a54d454',1,'generate_random_mark():&#160;my_lib.cpp'],['../my__lib_8cpp.html#a984b4252c352e01a48a56c7d6a54d454',1,'generate_random_mark():&#160;my_lib.cpp']]],
  ['generavimas_5ffailo_3',['generavimas_failo',['../my__lib_8h.html#ad40eb40134f8f6a319bb735ed5a6d11a',1,'Generavimas_failo(int skaic):&#160;my_lib.cpp'],['../my__lib_8cpp.html#ad40eb40134f8f6a319bb735ed5a6d11a',1,'Generavimas_failo(int skaic):&#160;my_lib.cpp']]],
  ['getmediana_4',['getMediana',['../class_studentas.html#a4823327b24f27594b50432e01664df87',1,'Studentas']]],
  ['getname_5',['getName',['../class_zmogus.html#ad09081a9463b42b80eba2ea745877095',1,'Zmogus']]],
  ['getpaz_6',['getPaz',['../class_studentas.html#ad3f38096e21f6463b8fe740a08f1fad3',1,'Studentas']]],
  ['getrez_7',['getRez',['../class_studentas.html#a0b5db276732ef0ce1151ac599bbb0661',1,'Studentas']]],
  ['getsurname_8',['getSurname',['../class_zmogus.html#a4f6dc26fb4b6a63bff6b7c4021c196c6',1,'Zmogus']]],
  ['gp_9',['GP',['../class_studentas.html#a23304690abeb04ca8e4de4c66f7858cf',1,'Studentas']]]
];
