var searchData=
[
  ['padalinimas_5fv_5f3_0',['padalinimas_v_3',['../my__lib_8h.html#a9e4f894e033e0f94b8c3983de6bc7d9b',1,'my_lib.h']]],
  ['pavarde_5f_1',['pavarde_',['../class_zmogus.html#a95b83ef4d9bbe9b88d78c17563bafa5a',1,'Zmogus']]]
];
