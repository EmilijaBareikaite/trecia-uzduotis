var searchData=
[
  ['setegzaminas_0',['setEgzaminas',['../class_studentas.html#a78c983307578dda3b4bdb988c1342793',1,'Studentas']]],
  ['setmediana_1',['setMediana',['../class_studentas.html#a73d76ddc34fc86841391382b9ca7c3bd',1,'Studentas']]],
  ['setpaz_2',['SetPAZ',['../class_studentas.html#ae2d94d1cd2be90b2997b8abdcbeb2666',1,'Studentas']]],
  ['setperson_3',['setPerson',['../class_zmogus.html#a7e1c9611fd558e2375a7e9724b4a5a7f',1,'Zmogus']]],
  ['setrez_4',['setRez',['../class_studentas.html#acacc4aaeccb979b47c8473c8a2584377',1,'Studentas']]],
  ['sortpaz_5',['SortPAZ',['../class_studentas.html#a132c7973352581aeb520c2de05a64703',1,'Studentas']]],
  ['studentas_6',['studentas',['../class_studentas.html',1,'Studentas'],['../class_studentas.html#ab459e995e8c9b24cdc9aec5b09a66539',1,'Studentas::Studentas()'],['../class_studentas.html#aef0484fe46cf05746f8ffc0d083fcf3e',1,'Studentas::Studentas(const Studentas &amp;other)']]]
];
