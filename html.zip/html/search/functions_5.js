var searchData=
[
  ['isrusiuotas_5fspausdinimas_0',['isrusiuotas_spausdinimas',['../my__lib_8h.html#af6171464ab0ca0ab7de11c08a376d5d1',1,'my_lib.h']]],
  ['isvedimas_5fm_1',['isvedimas_m',['../my__lib_8h.html#a7bc55580234cb86361001a578827dfb5',1,'my_lib.h']]],
  ['isvedimas_5fv_2',['isvedimas_v',['../my__lib_8h.html#a43082488f6da19d8b8b47073b2cec5eb',1,'my_lib.h']]]
];
