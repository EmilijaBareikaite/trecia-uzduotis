var searchData=
[
  ['vidurkis_0',['vidurkis',['../my__lib_8cpp.html#a4e65559221ffbc2e147c3a1b799bea8e',1,'Vidurkis(vector&lt; int &gt; paz):&#160;my_lib.cpp'],['../my__lib_8h.html#a4e65559221ffbc2e147c3a1b799bea8e',1,'Vidurkis(vector&lt; int &gt; paz):&#160;my_lib.cpp']]]
];
